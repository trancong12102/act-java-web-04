/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication77;

/**
 *
 * @author Vu Thi Anh Tuyet
 */
//Xây dựng ứng dụng soạn thảo văn bản đơn giản SimpleVim, ứng dụng có các chức năng
//1. Tạo 1 file mới (đường dẫn file được truyền vào)
//2. Người dùng có thể soạn nội dung cho file (nội dung file là text)
//3. Khi người dùng nhập vào kí tự :q chương trình sẽ dừng lại nhưng nội dung file và file không
//được lưu lại
//4. Khi người dùng nhập vào kí tự :wq chương trình sẽ dừng lại đồng thời toàn bộ nội dung soạn
//thảo được ghi lại vào file.
//5. Xem nội dung file bất kì ( giống như lệnh cat )

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Main {
    public static void main(String[] args) {
        FileManager myMan = new FileManager();
        try {
            myMan.manager();
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
    

