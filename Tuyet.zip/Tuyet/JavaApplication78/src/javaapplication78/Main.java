/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication78;

import java.util.Scanner;
//Rất nhiều chấm hỏi???

/**
 *
 * @author Vu Thi Anh Tuyet
 */
public class Main {

    public static void menu() {
        System.out.println("===Menu===");
        System.out.println(" 1.Load task");
        System.out.println(" 2.Add");
        System.out.println(" 3.Show all");
        System.out.print("Moi chon:> ");
    }

    public static void main(String[] args) {
        String filePath = "C:\\Users\\VuThiAnhTuyet\\Desktop\\text.txt";
        while (true) {
            menu();
            int option = new Scanner(System.in).nextInt();
            switch (option) {
                case 1:

                    break;
                case 2:

                    break;
                case 3:

                    break;
            }
        }
    }
}
