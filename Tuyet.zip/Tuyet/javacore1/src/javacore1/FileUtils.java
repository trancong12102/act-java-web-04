/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore1;

import java.io.*;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
//Xây dựng lớp FileUtils chứa các phương thức để thực hiện các yêu cầu sau ( mỗi yêu cầu viêt thành 1
//method trong lớp FileUtils)
//1. Lấy ra tất cả các folder có trong đường dẫn ( đường dẫn được truyền vào như là 1 tham số của
//hàm ).
//2. Lấy ra tất cả các file có trong đường dẫn ( đường dẫn là tham số của hàm )
//3. Lấy ra tất cả các file ảnh có trong đường dẫn ( file ảnh là file có đuổi .png, .jpg, .jpeg)
//4. Lấy ra tất cả các file có phần mở rộng ext có trong đường dẫn path ( ext và path là tham số
//truyền vào của hàm )
//5. Lấy ra thời gian cập nhật cuối cùng của file last modified time ( đường dẫn là tham số truyền
//vào )
//6. In ra kích thước của file, hiển thị theo type = Mb hoặc Kb ( type là tham số truyền vào)
//Xây dựng lớp Main, trong lớp Main sử dụng các phương thức của lớp FileUtils

/**
 *
 * @author Vu Thi Anh Tuyet
 */
public class FileUtils {

    private String filePath = null;
    private File folder;
    private String[] taiImg = {".png", ".pjg", ".jpeg"};

    public FileUtils() {
    }

    public FileUtils(String filePath) {
        this.filePath = filePath;
    }

    public void listAllFile(String filePath) {
        try {
            this.folder = new File(filePath);
            File[] file = folder.listFiles();
            System.out.println("File");
            for (File var : file) {
                if (var.isFile()) {
                    System.out.println("Name:> " + var.getName());
                }
            }
        } catch (NullPointerException e) {
            System.out.println("Khong tim thay");
        }

    }

    public void listAllFolder(String filePath) {
        try {
            this.folder = new File(filePath);
            File[] file = folder.listFiles();
            System.out.println("Folder");
            for (File var : file) {
                if (!var.isFile()) {
                    System.out.println("Name:> " + var.getName());
                }
            }
        } catch (NullPointerException e) {
            System.out.println("Khong tim thay");
        }
    }

    private boolean isImagne(String nameOfName) {
        for (String var : taiImg) {
            if (nameOfName.endsWith(var)) {
                return true;
            }
        }
        return false;
    }

    public void listAllImagne(String filePath) {
        try {
            this.folder = new File(filePath);
            File[] file = folder.listFiles();
            System.out.println("ANH: ");
            for (File var : file) {
                if (var.isFile()) {
                    if (isImagne(var.getName())) {
                        System.out.println("Name:> " + var.getName());
                    }
                }
            }
        } catch (NullPointerException e) {
            System.out.println("Khong tim thay");
        }
    }

    public void listAllTimeupDate(String filePath) {
        try {
            this.folder = new File(filePath);
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
            System.out.println(" Name:> " + folder.getName() + " Time:> "
                    + sdf.format(folder.lastModified()));
        } catch (NullPointerException e) {
            System.out.println("Khong tim thay");
        }
    }

    public void listAllSizeOfFile(String filePath) {
        try {
            this.folder = new File(filePath);
            File[] file = folder.listFiles();
            System.out.println("Size of file: ");
            for (File var : file) {
                int sizeOfFile = (int) Math.round(var.length() / 1000);
                System.out.println("Name:> " + var.getName() + " Size:> " + sizeOfFile + "kb");

            }
        } catch (NullPointerException e) {
            System.out.println("Khong tim thay");
        }
    }
}
