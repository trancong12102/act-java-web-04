/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore1;

/**
 *
 * @author Vu Thi Anh Tuyet
 */
public class Main {
    public static void main(String[] args) {
        String filepath1 = "C:\\Users\\Public\\Public Pictures";
        String filepath = "C:\\Program Files";
        FileUtils fileManager = new FileUtils();
        fileManager.listAllFolder(filepath);
        fileManager.listAllTimeupDate(filepath);
        fileManager.listAllSizeOfFile(filepath);
    }
}
