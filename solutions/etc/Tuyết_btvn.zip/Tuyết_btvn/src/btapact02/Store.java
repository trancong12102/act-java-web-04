/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package btapact02;

import java.util.Scanner;

/**
 *
 * @author Vu Thi Anh Tuyet
 */
public class Store {

    private Product[] arrProduct = new Product[100];
    private int number = 0;
    private static Scanner sc = new Scanner(System.in);

    public Store() {
    }

    public Store(Product[] arrProduct) {
        this.arrProduct = arrProduct;
    }

    public Product[] getArrProduct() {
        return arrProduct;
    }

    public void setArrProduct(Product[] arrProduct) {
        this.arrProduct = arrProduct;
    }

    public int getNumPro() {
        return number;
    }

    public void setNumPro(int numPro) {
        this.number = number;
    }

    public void add() {
        Product myPro = new Product();
        System.out.println("Moi ban chon:> ");
        System.out.println("1.SmartPhone \n  2.Camera");
        int option = sc.nextInt();
        switch (option) {
            case 1:
                myPro = new Camera();
                break;
            case 2:
                myPro = new Smartphone();
                break;
            default:
                System.out.println("Moi chon lai =)))");
                add();
                break;
        }
        myPro.addNew();
        arrProduct[number] = myPro;
        number++;
        this.setNumPro(number);
    }

    public void list() {
        System.out.printf("%15s|%5d|%5f|%5s", "Name", "ID",
                "Gia", "Chat luong");
        for (Product var : arrProduct) {
            var.showInfo();
        }
    }

    public void search() {
        System.out.println("Nhap vao 1 ten:>");
        String name = sc.nextLine();
        System.out.printf("%15s|%5d|%5f|%5s", "Name", "ID",
                "Gia", "Chat luong");
        for (Product var : arrProduct) {
            if (name.equals(var.getName())) {
                var.showInfo();
                return;
            }
        }
        System.out.println("Khong tim thay =)).");
    }
}
