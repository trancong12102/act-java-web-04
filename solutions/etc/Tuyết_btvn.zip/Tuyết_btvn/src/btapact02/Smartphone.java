/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package btapact02;

import java.util.Scanner;

/**
 *
 * @author Vu Thi Anh Tuyet
 */
public class Smartphone extends Product {

    private boolean hasCamera;
    private int sim;

    public Smartphone() {
    }

    public Smartphone(boolean hasCamera, int sim) {
        this.hasCamera = hasCamera;
        this.sim = sim;
    }

    public Smartphone(boolean hasCamera, int sim, int id, String name, double price, int quantity) {
        super(id, name, price, quantity);
        this.hasCamera = hasCamera;
        this.sim = sim;
    }

    public boolean isHasCamera() {
        return hasCamera;
    }

    public void setHasCamera(boolean hasCamera) {
        this.hasCamera = hasCamera;
    }

    public int getSim() {
        return sim;
    }

    public void setSim(int sim) {
        this.sim = sim;
    }

    @Override
    public void addNew() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Infor Smartphone");
        System.out.println("Co sim:>");
        System.out.println("1. co      2. khong");
        int hasCam = sc.nextInt();
        System.out.println("Sim:>");
        sim = sc.nextInt();
        this.setSim(sim);
        sc.nextLine();
        super.addNew();
    }

    @Override
    public void showInfo() {
        super.showInfo();
        System.out.printf("%11d|%5s|\n", this.getSim(), this.isHasCamera());
    }
}
