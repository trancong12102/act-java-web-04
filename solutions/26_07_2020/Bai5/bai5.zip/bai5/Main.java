/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5;

/**
 *
 * @author oOOo
 */
public class Main {
    public static void main(String[] args) {
        Triangle t=new Triangle();
        t.nhap();
        t.kieuTriangle();
        t.chuviTriangle();
        t.dientichTriangle();
    }
}
