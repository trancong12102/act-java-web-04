/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5;

import java.util.Scanner;

/**
 *
 * @author oOOo
 */
public class Triangle {

    private double a;
    private double b;
    private double c;

    public Triangle() {

    }

    public Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public void setA(double a) {
        this.a = a;
    }

    public void setB(double b) {
        this.b = b;
    }

    public void setC(double c) {
        this.c = c;
    }

    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }

    public double getC() {
        return c;
    }

    public void nhap() {
        System.out.println("nhap a:");
        setA(new Scanner(System.in).nextDouble());
        System.out.println("nhap b:");
        setB(new Scanner(System.in).nextDouble());
        System.out.println("nhap c:");
        setC(new Scanner(System.in).nextDouble());
    }

    public void kieuTriangle() {
        if (a + b <= c || a + c <= b || b + c <= a) {
            System.out.println("day ko phai tam giac");
        } else {
            if (a == b && a == c && b == c) {
                System.out.println("tam giac deu");
            }
            if (a == b && a == c || a == c && b == c && a == b && b == c) {
                System.out.println("tam giac can");
            }
            if (a * a == b * b + c * c || b * b == a * a + c * c || c * c == a * a + b * b) {
                System.out.println("tam giac vuong");
            } else {
                System.out.println("tam giac nhon");
            }
        }
    }

    public void chuviTriangle() {
        double cv = getA() + getB() + getC();
        System.out.println("chu vi tam giac la` :" + cv);

    }

    public void dientichTriangle() {
        double p = (getA() + getB() + getC()) / 2;
        double dientich =  Math.sqrt(p * (p - getA()) * (p - getB()) * (p - getC()));
        System.out.println("dien tich tam giac:" + dientich);

    }
}
