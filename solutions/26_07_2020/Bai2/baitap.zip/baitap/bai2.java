/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baitap;
        
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author oOOo
 */
public class bai2 {
    public static void main(String[] args) {
        Nhap n=new Nhap();
        n.inputInfo();
        n.printInfo();
        n.hocbong();
        /* String email=new String();
        email="duynien01668611460@gmail.com";
        System.out.println(email.charAt(0));
        System.out.println(email.indexOf("@"));
        System.out.println(email.substring(email.indexOf("@"), email.length()) );
        System.out.println(email.replace("com", "vn"));
        if(email.substring(email.indexOf("@"), email.length()).compareTo("@gmail.com")==0)
           System.out.println("dung la 1 email");
           else System.out.println("khong phai");
//        StringBuffer sb=new StringBuffer(email);
 //       sb.append(",chimsebandem@gmail.com");
  //      System.out.println(sb);
     //   StringTokenizer st=new StringTokenizer("toi lam viec o ha noi");
      //  while(st.hasMoreTokens()){
         //   System.out.println(st.nextToken());
      //  }
        /*int[] arr={1,6,7,2,5,9};
        System.out.println(arr.length);
        Arrays.sort(arr);
        System.out.println(Arrays.binarySearch(arr,5));
        int[] copy=Arrays.copyOfRange(arr,2,4);
        System.out.println(copy);*/
}
}
