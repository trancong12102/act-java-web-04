
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.NotSerializableException;
import java.util.*;
public class CustomerManager implements Serializable {
    private ArrayList<Customer> listCus = new ArrayList<Customer>();
    private int numberCus = 0;
    private Customer cus = new Customer();
     public boolean load(){
        File f = new File("C:\\Bai12\\CusList.dat");
        try{
            FileInputStream fis = new  FileInputStream(f);
            ObjectInputStream oCus = new ObjectInputStream(fis);
            for( int i=0; i<numberCus; i++){
                cus = (Customer) oCus.readObject();
                listCus.add(cus);
            }
            fis.close();
            oCus.close();
        }
        catch(FileNotFoundException efnf){
            return false;
        }
        catch(IOException ioe){
            return false;
        }
        catch (ClassNotFoundException ex) {
            return false;
        }
        return true;
    }
    
    public void add(){
        String name, id, age, address;
       try{
            System.out.println("Dien thong tin:>");
            System.out.print("Nhap id:>");
            cus.setId(Integer.parseInt(new Scanner(System.in).nextLine()));
            System.out.print("Nhap ten:>");
            cus.setName(new Scanner(System.in).nextLine());
            System.out.print("Nhap dia chi:>");
            cus.setAddress(new Scanner(System.in).nextLine());
            System.out.print("Nhap tuoi:>");
            cus.setAge(Integer.parseInt(new Scanner(System.in).nextLine()));
       }catch(Exception e){
       }
        System.out.print("Co muon luu khong???\n y. co\t n.No");
        boolean choice = (new Scanner(System.in).nextLine()).equals("y");
       
        if(choice)
            if(save())
                System.out.println("Luu thành công");
            else
                System.out.println("Lưu thât bại.");

    }
    
    private boolean save(){
        File f = new File("C:\\Bai12\\CusList.dat");
        try{
            FileOutputStream fos = new FileOutputStream(f);
            ObjectOutputStream oCus = new ObjectOutputStream(fos);
            oCus.writeObject(this.cus);
            this.numberCus = numberCus+1;
            fos.close();
            oCus.close();
        }catch(FileNotFoundException e){
            System.out.println(e.toString());
            return false;
        }catch(IOException ioe){
            System.out.println(ioe.toString());
            return false;
        }
        return true;
    }
    
   
   
    
   
}