/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt2;

import java.util.*;

/**
 *
 * @author topmu
 */
public class Student {
    private String MaSV,lop;
    private float Diem;
    private int Tuoi;
    private char l;

    public Student(String MaSV, String lop, float Diem, int Tuoi)
    {
        this.MaSV = MaSV;
        this.lop = lop;
        this.Diem = Diem;
        this.Tuoi = Tuoi;
    }

    public Student() { }

    public String getMaSV() {
        return MaSV;
    }

    public void setMaSV(String MaSV) {
        this.MaSV = MaSV;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public float getDiem() {
        return Diem;
    }

    public void setDiem(float Diem) {
        this.Diem = Diem;
    }

    public int getTuoi() {
        return Tuoi;
    }

    public void setTuoi(int Tuoi) {
        this.Tuoi = Tuoi;
    }
    public void inputinfor()
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Nhập Mã Sinh Viên: ");
        MaSV=sc.nextLine();
        System.out.println("Nhập Điểm Trung Bình Sinh Viên: ");
        Diem=sc.nextFloat();
        System.out.println("Nhập Tuổi Sinh Viên:(Lớn Hơn 18) ");
        Tuoi=sc.nextInt();
        if(Tuoi<18)
        {
            System.out.println("Nhập Lại Tuổi Sinh Viên:(Lớn Hơn 18) ");
            Tuoi=sc.nextInt();
        }
        System.out.print("Nhập Lớp SV bắt đầu bằng A Hoặc C ");
        lop=sc.nextLine();
        //l = lop.charAt(0);
        //if("c".equals(0)||"C".equals(l)||"A".equals(l)||"a".equals(l))
        //{
        //    System.out.println("Nhập Lại Lớp SV bắt đầu bằng A Hoặc C ");
        //    lop=sc.nextLine();
        //}
    }
    public void showinfor()
    {
        System.out.println("Mã Sinh Viên: "+getMaSV());
        System.out.printf("Điểm Trung Bình Sinh Viên: %.1f ",getDiem());
        System.out.println("\nTuổi Sinh Viên:(Lớn Hơn 18) "+getTuoi());
        System.out.println("Lớp Sinh Viên là:"+getLop());
    }
    public void Hoc_bong()
    {
        if(Diem>=8.0)
        {
            System.out.println("Sinh Viên Đạt Được Học Bổng");
        }
        else
        {
            System.out.println("Sinh Viên Không Được Nhận Học Bổng");
        }
    }
        
 }
