/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt2;

/**
 *
 * @author topmu
 */
public class HaiBT2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Student SV = new Student("at15", "a10", (float) 9.25, 17);
        Student SV = new Student();
        SV.inputinfor();
        SV.showinfor();
        SV.Hoc_bong();
    }
    
}
