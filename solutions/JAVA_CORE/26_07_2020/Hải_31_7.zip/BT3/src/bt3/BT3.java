/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bt3;

import java.util.Scanner;

/**
 *
 * @author topmu
 */
public class BT3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        boolean key1=false,key2=false,key3=false,key4=false;
        String a,b;
        float c,d;
        Scanner sc = new Scanner (System.in);
        System.out.println("Nếu Bạn là học viên của HDSE gõ c:");
        a=sc.nextLine();
        System.out.println("Nếu Bạn vi nội quy trung tâm gõ c:");
        b=sc.nextLine();
        System.out.println("Điểm Tổng Kết của bạn là:");
        d=sc.nextFloat();
        System.out.println("Mỗi kỳ thi bạn thi mấy lần");
        c=sc.nextFloat();
        
        
        if("c".equals(a)||"C".equals(a))
        {
            key1= true;
        }
        if(d>=75)
        {
            key2= true;
        }
        if("c".equals(a)||"C".equals(b))
        {
            key3= true;
        }
        if(c==1)
        {
            key4= true;
        }
        if(key1==true&&key2==true&&key3==true&&key4==true)
        {
            System.out.println("Học Viên được nhận học bổng");
        }
        else
        {
            System.out.println("Học Viên Không được nhận học bổng");
        }
        
         
    }
    
}
