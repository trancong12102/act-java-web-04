/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt1;

import java.util.Scanner;

/**
 *
 * @author topmu
 */
public class nhanvien {
    private String Ten,Dia_chi;
    private int Tuoi,Gio_lam;
    private double lương;

    public nhanvien(String Ten, String Dia_chi, int Tuoi, int Gio_lam, double lương) {
        this.Ten = Ten;
        this.Dia_chi = Dia_chi;
        this.Tuoi = Tuoi;
        this.Gio_lam = Gio_lam;
        this.lương = lương;
    }

    public nhanvien() { }

    public String getTen() {
        return Ten;
    }

    public void setTen(String Ten) {
        this.Ten = Ten;
    }

    public String getDia_chi() {
        return Dia_chi;
    }

    public void setDia_chi(String Dia_chi) {
        this.Dia_chi = Dia_chi;
    }

    public int getTuoi() {
        return Tuoi;
    }

    public void setTuoi(int Tuoi) {
        this.Tuoi = Tuoi;
    }

    public int getGio_lam() {
        return Gio_lam;
    }

    public void setGio_lam(int Gio_lam) {
        this.Gio_lam = Gio_lam;
    }

    public double getLương() {
        return lương;
    }

    public void setLương(double lương) {
        this.lương = lương;
    }
    public void Inputinfor()
    {
        Scanner sc = new Scanner (System.in);
        System.out.printf("Nhập Tên Nhân viên: ");
        Ten=sc.nextLine();
        System.out.printf("\nNhập Địa Chỉ Nhân Viên: ");
        Dia_chi=sc.nextLine();
        System.out.printf("\nNhập Tuổi Nhân Viên: ");
        Tuoi=sc.nextInt();
        System.out.printf("\nNhập Lương Nhân viên: ");
        lương=sc.nextDouble();
        System.out.printf("\nNhập Thời Gian Làm Việc Của Nhân viên: ");
        Gio_lam=sc.nextInt();
    }
    public void printinfor()
    {
        System.out.printf("Tên Nhân viên: "+getTen());
        System.out.printf("\nĐịa Chỉ Nhân Viên: "+getDia_chi());
        System.out.printf("\nTuổi Nhân Viên: "+getTuoi());
        System.out.printf("\nLương Nhân viên: "+getLương());
        System.out.printf("\nThời Gian Làm Việc Của Nhân viên: "+getGio_lam());
    }
    public void Tinh_Thuong()
    {
        double thuong;
        if (Gio_lam<100)
        {
            System.out.println("\nNhân Viên không được thưởng");
        }
        if (100<=Gio_lam&&Gio_lam<200)
        {
            thuong = lương*0.1;
            System.out.println("\nNhân Viên được thưởng: "+thuong);
        }
        if (200<=Gio_lam)
        {
            thuong = lương*0.2;
            System.out.println("\nNhân Viên được thưởng: "+thuong);
        }
    }
}
