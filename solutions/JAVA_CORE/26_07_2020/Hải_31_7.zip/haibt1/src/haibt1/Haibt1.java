/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt1;

/**
 *
 * @author topmu
 */
public class Haibt1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //nhanvien NV = new nhanvien();
        nhanvien NV =new nhanvien("hai", "hai", 25, 250, 250);
        //NV.Inputinfor();
        NV.printinfor();
        NV.Tinh_Thuong();
    }
    
}
