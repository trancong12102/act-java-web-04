/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt5;

import java.util.Scanner;

/**
 *
 * @author topmu
 */
public class Triangle {
    private int a,b,c;

    public Triangle() {}
    
    public void Nhap()
    {
        Scanner sc = new Scanner(System.in);
        do
        {    
            System.out.println("Nhập Cạnh a");
            a=sc.nextInt();
            System.out.println("Nhập Cạnh b");
            b=sc.nextInt();
            System.out.println("Nhập Cạnh c");
            c=sc.nextInt();
        }
        while(a>=b+c&&b>=a+c&&c>=a+b);
    }
    public void Kieu_Tam_Giac()
    {
        boolean key = false;
        if(a==b&&b==c)
        {
            System.out.println("Tam Giác là tam giác đều");
            key=true;
        }
        if((a==b&&a!=c)||(a==c&&a!=b)||(c==b&&b!=c))
        {
            System.out.println("Tam Giác là tam giác cân");
            key=true;
        }
        if((c*c==a*a+b*b) || (a*a==b*b+c*c) || (a*a+c*c==b*b))
        {
            System.out.println("Tam Giác là tam giác Vuông");
            key=true;
        }
        
        if(key=false)
        {
            System.out.println("Tam Giác là tam giác thường");
        }
    }
    public void Chu_vi()
    {
        int C=a+b+c;
        System.out.println("Chu vi Tam Giác Là: "+C);
    }
    public void Dien_Tich()
    {
        int C=a+b+c;
        float S;
        S=(float)Math.sqrt((C/2)*(C/2-a)*(C/2-b)*(C/2-c));
        System.out.println("Diện Tích Tam Giác Là: "+S);
    }
}
