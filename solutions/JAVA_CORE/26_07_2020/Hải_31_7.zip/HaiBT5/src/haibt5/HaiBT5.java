/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt5;

/**
 *
 * @author topmu
 */
public class HaiBT5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Triangle T = new Triangle();
        T.Nhap();
        T.Kieu_Tam_Giac();
        T.Chu_vi();
        T.Dien_Tich();
    }
    
}
