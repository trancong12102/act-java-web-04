/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diu1;

/**
 *
 * @author 14022000
 */


import java.io.PrintStream;
import java.util.Scanner;

/**
 *
 * @author topmu
 */
public class nhanvien {
    private String Ten,Dia_chi;
    private int Tuoi,Gio_lam;
    private double Tien_luong;

    public nhanvien(String Ten, String Dia_chi, int Tuoi, int Gio_lam, double Tien_luong) {
        this.Ten = Ten;
        this.Dia_chi = Dia_chi;
        this.Tuoi = Tuoi;
        this.Gio_lam = Gio_lam;
        this.Tien_luong = Tien_luong;
    }

    public nhanvien() { }

    public String getTen() {
        return Ten;
    }

    public void setTen(String Ten) {
        this.Ten = Ten;
    }

    public String getDia_chi() {
        return Dia_chi;
    }

    public void setDia_chi(String Dia_chi) {
        this.Dia_chi = Dia_chi;
    }

    public int getTuoi() {
        return Tuoi;
    }

    public void setTuoi(int Tuoi) {
        this.Tuoi = Tuoi;
    }

    public int getGio_lam() {
        return Gio_lam;
    }

    public void setGio_lam(int Gio_lam) {
        this.Gio_lam = Gio_lam;
    }

    public double getTien_luong() {
        return Tien_luong;
   }

    void Tinh_Thuong() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void Tien_luong(double Tien_luong) {
        this.Tien_luong = Tien_luong;
    }
    public void Inputinfor()
    {
        Scanner sc = new Scanner (System.in);
        System.out.printf("nhập tên nhân viên: ");
        Ten=sc.nextLine();
        System.out.printf("\n nhập địa chỉ nhân viên: ");
        Dia_chi=sc.nextLine();
        System.out.printf("\nnhập tuổi nhân viên: ");
        Tuoi=sc.nextInt();
        System.out.printf("\n nhập tiền lương nhân viên: ");
        Tien_luong=sc.nextDouble();
        System.out.printf("\n nhập giờ làm nhân viên: ");
        Gio_lam=sc.nextInt();
    }
    public void printinfor()
    {
        
    }

    /**
     *
     */
    public void Inputinfor()
    {
        Scanner sc = new Scanner (System.in);
        PrintStream printf = System.out.printf("nhập tên nhân viên:");
        Ten=sc.nextLine();
        System.out.printf("\n nhập địa chỉ nhân viên: ");
        Dia_chi=sc.nextLine();
        System.out.printf("\n nhập tuổi nhân viên: ");
        Tuoi=sc.nextInt();
        System.out.printf("\n nhập tiềm lương nhân viên: ");
        Tien_luong=sc.nextDouble();
        System.out.printf("\n nhập giờ làm nhân viên: ");
        Gio_lam=sc.nextInt();
    }
    public void printinfor()
    {

        double thuong = Tien_luong*0.1;
            System.out.println("\nNhÃ¢n ViÃªn Ä‘Æ°á»£c thÆ°á»Ÿng: "+thuong);
        }
        if (200<=Gio_lam)
        {
        double thuong = Tien_luong*0.2;
            System.out.println("\nNhÃ¢n ViÃªn Ä‘Æ°á»£c thÆ°á»Ÿng: "+thuong);
        }
    }


    

