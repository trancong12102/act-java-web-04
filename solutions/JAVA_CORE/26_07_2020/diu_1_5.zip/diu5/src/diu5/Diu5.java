/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diu5;

/**
 *
 * @author 14022000
 */
public class Diu5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SoNguyenTo SNT = new SoNguyenTo(8);
    }

    }
    

