/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diu5;

/**
 *
 * @author 14022000
 */
final class SoNguyenTo {
    private int a,x;

    public SoNguyenTo() {  }

    public SoNguyenTo(int x) {
        if(isSoNguyenTo(x)==true)
        {
            this.a=x;
            System.out.printf("%d là số nguyên ttos¯\n",x);
            System.out.println("số nguyên tố tiếp theo "+timSoNguyenToTiepTheo());
        }
        else
        {
            System.out.printf("%d không phải là số ngyteen tố‘, khÃ´ng lÆ°u trá»¯",x);

        }
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }
    boolean isSoNguyenTo(int x)
    {
        boolean key = true;
        if (x<2)
        {
            key = false ;
}
        else
        {
            for(int i=2; i<=Math.sqrt(x);i++)
            {
                if(x%i==0)
                {
                    key=false;
                    break;
                }             
            }
        }
        return key;
    }
     int timSoNguyenToTiepTheo()
     {
         int nguyentotiep;
         int i=0;
         while (true)
         {
             if (isSoNguyenTo(this.a + ++i)==true)
             {
                 return this.a + i;
             }
         }
     }
}

    

