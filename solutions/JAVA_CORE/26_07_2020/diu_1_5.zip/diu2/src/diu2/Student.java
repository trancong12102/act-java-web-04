/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diu2;

import java.util.Scanner;

/**
 *
 * @author 14022000
 */
class Student {
    private String MaSV,lop;
    private float Diem;
    private int Tuoi;
    private char l;

    public Student(String MaSV, String lop, float Diem, int Tuoi)
    {
        this.MaSV = MaSV;
this.lop = lop;
        this.Diem = Diem;
        this.Tuoi = Tuoi;
    }

    public Student() { }

    public String getMaSV() {
        return MaSV;
    }

public void setMaSV(String MaSV) {
        this.MaSV = MaSV;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public float getDiem() {
        return Diem;
    }

    public void setDiem(float Diem) {
        this.Diem = Diem;
    }

    public int getTuoi() {
        return Tuoi;
    }

    public void setTuoi(int Tuoi) {
        this.Tuoi = Tuoi;
    }
    public void inputinfor()
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Nhaập mã sinh viên: ");
        MaSV=sc.nextLine();
        System.out.println("Nhập điểm trung bình nhân viên: ");
        Diem=sc.nextFloat();
        System.out.println("Nhập tuổi sinh viên:(Lá»›n HÆ¡n 18) ");
        Tuoi=sc.nextInt();
        if(Tuoi<18)
        {
            System.out.println("nhập tuổi sinh viên:(Lá»›n HÆ¡n 18) ");
            Tuoi=sc.nextInt();
        }
        System.out.print("Nháº­p Lá»›p SV báº¯t Ä‘áº§u báº±ng A Hoáº·c C ");
        lop=sc.nextLine();
       
    }
    public void showinfor()
    {
        System.out.println("mã sinh viên: "+getMaSV());
        System.out.printf("Điểm trung bifmh nhân viên\n: %.1f ",getDiem());
        System.out.println("\ntuổi sinh viên:(hiện là 18 18) "+getTuoi());
        System.out.println("Lá»›p Sinh ViÃªn lÃ :"+getLop());
    }
    public void Hoc_bong()
    {
        if(Diem>=8.0)
        {
            System.out.println("Sinnh viên dduowwjc học bổng");
        }
        else
        {
            System.out.println("Sinh viên k đk hok bổng");
        }
    }
        
 }

    

