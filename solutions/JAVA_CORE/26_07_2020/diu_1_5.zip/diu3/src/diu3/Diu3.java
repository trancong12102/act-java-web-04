/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diu3;

import java.util.Scanner;

/**
 *
 * @author 14022000
 */
public class Diu3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean key1=false,key2=false,key3=false,key4=false;
        String a,b;
        float c,d;
        Scanner sc = new Scanner (System.in);
        System.out.println("la hok viên dawng kí khóa học HDSE:");
        a=sc.nextLine();
        System.out.println("không vi phạm nội quy trung tâm:");
        b=sc.nextLine();
        System.out.println("điểm to9orng kết trung bình khá:");
        d=sc.nextFloat();
        System.out.println("vác kì thi chỉ lần đầu tiên:");
        c=sc.nextFloat();

        if("c".equals(a)||"C".equals(a))
        {
            key1= true;
        }
        if(d>=75)
        {
            key2= true;
        }
        if("c".equals(a)||"C".equals(b))
        {
            key3= true;
        }
        if(c==1)
        {
            key4= true;
        }
        if(key1==true&&key2==true&&key3==true&&key4==true)
        {
            System.out.println("học viên sẽ được hok bổng");
        }
        else
        {
            System.out.println("học viên không được hok bổng");
        }
        
         
    }
    
}

    
    

