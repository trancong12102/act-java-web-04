/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt12;

/**
 *
 * @author topmu
 */
public class hinhchunhat extends dagiac{

    public hinhchunhat(int a, int b) {
        super(a, b);
    }

    public hinhchunhat() {
    }

    @Override
    public int getA() {
        return a;
    }

    @Override
    public void setA(int a) {
        this.a = a;
    }

    @Override
    public int getB() {
        return b;
    }

    @Override
    public void setB(int b) {
        this.b = b;
    }
    @Override
    public void Nhập()
    {
        super.Nhập();
    }
    @Override
    public  void Chuvi()
    {
        super.Chuvi();
    }
    @Override
    public void Tich()
    {
        super.Tich();
    }
    
}
