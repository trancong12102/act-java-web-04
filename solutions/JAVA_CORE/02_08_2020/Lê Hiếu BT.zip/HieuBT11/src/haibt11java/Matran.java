/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt11java;

import java.util.Scanner;

/**
 *
 * @author topmu
 */
public class Matran {
    int [][] A= new int[100][100];
    int [][] B= new int[100][100];
    int n,m;

    public Matran() {
    }
    public Matran(int[][] A, int[][] B) {
        this.A = A;
        this.B = B;
    }

    public int[][] getB() {
        return B;
    }

    public void setB(int[][] B) {
        this.B = B;
    }

    public int[][] getA() {
        return A;
    }

    public void setA(int[][] A) {
        this.A = A;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }
    
    public void NHap()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập kích thương ma trận vuông n:");
        n=sc.nextInt();
        for (int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                System.out.println("Nhập phần tử A["+i+j+"]");
                A[i][j]=sc.nextInt();
            }
        }
        for (int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                System.out.println("Nhập phần tử B["+i+j+"]");
                B[i][j]=sc.nextInt();
            }
        }
        
    }
    public  void Tong()
    {
        System.out.println("Tổng 2 ma trận là:");
        for (int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                m=this.A[i][j]+this.B[i][j];
                System.out.printf(m+"   ");    
            }
            System.out.println("");
            System.out.println("");
        }    
    }
    public void Tich()
    {
        System.out.println("Tích 2 Ma Trận là:");
        for(int i = 0;i<n;i++)
        {
            for(int j = 0;j<n;j++) 
            {
               
                    m =0;
                    m = 0 + this.A[i][j]*this.B[i][j];
                    System.out.printf(m+"  ");
                
            }
            System.out.println("");
            System.out.println(""); 
       }
  
    }
}
