/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt6java;

import java.util.Scanner;

/**
 *
 * @author topmu
 */
public class hinhchunhat {
    float chieudai,chieurong;

    public hinhchunhat(float chieudai, float chieurong) {
        this.chieudai = chieudai;
        this.chieurong = chieurong;
    }

    public hinhchunhat() {
    }

    public float getChieudai() {
        return chieudai;
    }

    public void setChieudai(float chieudai) {
        this.chieudai = chieudai;
    }

    public float getChieurong() {
        return chieurong;
    }

    public void setChieurong(float chieurong) {
        this.chieurong = chieurong;
    }
    public void Nhap()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập kích thước chiều rộng của hình chữ nhật:");
        chieurong=sc.nextFloat();
        System.out.println("Nhập kích thước chiều dai của hình chữ nhật:");
        chieudai=sc.nextFloat();
    }
    public  void Dien_Tich()
    {
        System.out.println("Diện tích hình chữ nhật là S = " +(chieudai*chieurong));
        
    }
    public  void CHu_vi()
    {
        System.out.println("Diện tích hình chữ nhật là S = " +(2*chieudai+2*chieurong));
        
    }
    
    
}
