/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt7java;

/**
 *
 * @author topmu
 */
public class HAIBT7java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        phanso ps1 = new phanso();
        phanso ps2 = new phanso(4,8);
        ps1.Nhap();
        ps1.IN();
        ps1.Ngichdao();
        ps1.add(ps2);
        ps1.sub(ps2);
        ps1.mul(ps2);
        ps1.div(ps2);
    }
    
}
