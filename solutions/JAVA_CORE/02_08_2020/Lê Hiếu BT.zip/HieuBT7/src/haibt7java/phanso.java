/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt7java;

import java.util.Scanner;

/**
 *
 * @author topmu
 */
public class phanso {
    int tuso,mauso;

    public phanso() {    }

    public phanso( int tuso, int mauso) {
        this.tuso = tuso;
        this.mauso = mauso;
    }

    public int getTuso() {
        return tuso;
    }

    public void setTuso(int tuso) {
        this.tuso = tuso;
    }

    public int getMauso() {
        return mauso;
    }

    public void setMauso(int mauso) {
        this.mauso = mauso;
    }
    public void Nhap()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập tử số: ");
        tuso=sc.nextInt();
        System.out.println("Nhập mẫu số: ");
        mauso=sc.nextInt();
    }
    public int timUSCLN(int a, int b) {
        while (a != b) {
            if (a > b) {
                a -= b;
            } else {
                b -= a;
            }
        }
        return a;
    }
    public void IN()
    {
        System.out.printf("Phân số vừa nhập là: %d/%d \n",getTuso(),getMauso());
    }
    public void Rutgon()
    {
        int i = timUSCLN(this.tuso, this.mauso);
        this.setTuso((int) (this.getTuso()/i));
        this.setMauso((int) (this.getMauso()/i));
    }
    public void Ngichdao()
    {
        System.out.printf("Phân số Nghịch đảo là:%d/%d \n",this.getMauso(),this.getTuso());
    }
    public void add(phanso ps)
    {
        int ts = this.getTuso() * ps.getMauso() + ps.getTuso() * this.getMauso();
        int ms = this.getMauso() * ps.getMauso();
        phanso phanSoTong = new phanso(ts, ms);
        phanSoTong.Rutgon();
        System.out.println("Tổng hai phân số = " + phanSoTong.tuso + "/" + phanSoTong.mauso);
    }
      
    public void sub(phanso ps) {
        int ts = this.getTuso()* ps.getMauso()- ps.getTuso()* this.getMauso();
        int ms = this.getMauso()* ps.getMauso();
        phanso phanSoHieu = new phanso(ts, ms);
        phanSoHieu.Rutgon();
        System.out.println("Hiệu hai phân số = " + phanSoHieu.tuso + "/" + phanSoHieu.mauso);
    }
     
    public void mul(phanso ps) {
        int ts = this.getTuso()* ps.getTuso();
        int ms = this.getMauso()* ps.getMauso();
        phanso phanSoTich = new phanso(ts, ms);
        phanSoTich.Rutgon();
        System.out.println("Tích hai phân số = " + phanSoTich.tuso + "/" + phanSoTich.mauso);
    }
     
    public void div(phanso ps) {
        int ts = this.getTuso()* ps.getMauso();
        int ms = this.getMauso()* ps.getTuso();
        phanso phanSoThuong = new phanso(ts, ms);
        phanSoThuong.Rutgon();
        System.out.println("Thương hai phân số = " + phanSoThuong.tuso + "/" + phanSoThuong.mauso);
    }
}
    
    
    
    
    
