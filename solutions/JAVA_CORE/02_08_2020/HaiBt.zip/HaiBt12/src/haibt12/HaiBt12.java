/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt12;

import java.util.Scanner;

/**
 *
 * @author topmu
 */
public class HaiBt12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        hinhbinhhanh hbh =new hinhbinhhanh();
        hinhchunhat hcn = new hinhchunhat();
        hinhvuong hv = new hinhvuong();
        do 
        {
            System.out.println("Chọn1 để chọn Hình Bình Hành");
            System.out.println("chọn2 để chọn Hình CHữ Nhật");
            System.out.println("CHọn 3 Để Chọn Hình Vuông");
            System.out.println("chọn 4 để thoát");
            int key = sc.nextInt();
            switch(key)
            {
                case 1:
                {
                    hbh.Nhập();
                    hbh.Chuvi();
                    hbh.Tich();
                    break;
                }
                case 2:
                {
                    hcn.Nhập();
                    hcn.Chuvi();
                    hcn.Tich();
                    break;
                }
                case 3:
                {
                    hv.Nhập();
                    hv.Chuvi();
                    hv.Tich();
                    break;
                }
                case 4:
                {
                    return;
                }
            }
        } while (true);
    }
    
}
