/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt12;
    import java.util.Scanner;
/**
 *
 * @author topmu
 */
public class dagiac {
    int a,b;

    public dagiac(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public dagiac() {
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }
    public void Nhập()
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Nhập cạnh a");
        this.a=sc.nextInt();
        System.out.println("Nhập cạnh b");
        this.b=sc.nextInt();
        
    }
    public void Tich()
    {
        System.out.println("Tích của Hình là:"+(getA()*getB()));
    }
    public void Chuvi()
    {
        System.out.println("Chu vi của Hình là:"+(2*getA()+2*getB()));
    }
}
