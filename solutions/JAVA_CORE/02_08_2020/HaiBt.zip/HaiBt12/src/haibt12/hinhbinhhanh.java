/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt12;

import java.util.Scanner;

/**
 *
 * @author topmu
 */
public class hinhbinhhanh extends dagiac{
    int c;

    public hinhbinhhanh(int c, int a, int b) {
        super(a, b);
        this.c = c;
    }

    public hinhbinhhanh(int c) {
        this.c = c;
    }

    public hinhbinhhanh() {
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }

    @Override
    public int getA() {
        return a;
    }

    @Override
    public void setA(int a) {
        this.a = a;
    }

    @Override
    public int getB() {
        return b;
    }

    @Override
    public void setB(int b) {
        this.b = b;
    }
    
    @Override
    public void Nhập()
    {
        Scanner sc = new Scanner(System.in);
        super.Nhập();
        System.out.println("Nhập chiều cao hình bình hành");
        c=sc.nextInt();
    }
    @Override
    public void Chuvi()
    {
        super.Chuvi();
    }
    @Override
    public void Tich()
    {
        if(this.a<=this.b)
        {
            this.a = this.c;
        }
        else
        {
             this.b = this.c;
        }
       
        super.Tich();
    }
    
}
