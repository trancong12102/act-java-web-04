/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt12;

import java.util.Scanner;

/**
 *
 * @author topmu
 */
public class hinhvuong extends hinhchunhat{

    public hinhvuong() {
    }

    public hinhvuong(int a, int b) {
        super(a, b);
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }
        @Override
    public void Nhập()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập cạnh hình vuông");
        this.a=sc.nextInt();
        this.b=this.a;
    }
    @Override
    public  void Chuvi()
    {
        super.Chuvi();
    }
    @Override
    public void Tich()
    {
        
        super.Tich();
    }
    
    
}
