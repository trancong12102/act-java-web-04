/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt8java;

/**
 *
 * @author topmu
 */
public class sophuc {
    int thuc,ao;

    public sophuc(int thuc, int ao) {
        this.thuc = thuc;
        this.ao = ao;
    }

    public sophuc() {
    }

    public int getThuc() {
        return thuc;
    }

    public void setThuc(int thuc) {
        this.thuc = thuc;
    }

    public int getAo() {
        return ao;
    }

    public void setAo(int ao) {
        this.ao = ao;
    }
    public  void Cong(sophuc sp)
    {
        int T =this.getThuc()+ sp.getThuc();
        int A = this.getAo() + sp.getAo();
        System.out.println("Tổng 2 số thực là z = "+T+" + "+A+"i");
    }
    public  void Tru(sophuc sp)
    {
        int T =this.getThuc()- sp.getThuc();
        int A = this.getAo() - sp.getAo();
        System.out.println("Hieu 2 số thực là z = "+T+" + "+A+"i");
    }
    public  void Nhan(sophuc sp)
    {
        int T =this.getThuc()* sp.getThuc()-this.getAo() * sp.getAo();
        int A = this.getThuc() * sp.getAo()+this.getAo()*sp.getThuc();
        System.out.println("Tích 2 số thực là z = "+T+" + "+A+"i");
    }
     public  void Thuong(sophuc sp)
    {
        float T =(float)(this.getThuc()* sp.getThuc()+this.getAo() * sp.getAo())/(sp.getAo()*sp.getAo()+sp.getThuc()*sp.getThuc());
        float A =(float)(sp.getThuc()* getAo()-this.getThuc() * sp.getAo())/(sp.getAo()*sp.getAo()+sp.getThuc()*sp.getThuc());
        System.out.println("Tích 2 số thực là z = "+T+" + "+A+"i");
    }
    
    
}
