/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt8java;

/**
 *
 * @author topmu
 */
public class HAibt8java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        sophuc sophuc1 = new sophuc(4, 5);
        sophuc sophuc2 = new sophuc(1, 5);
        sophuc1.Cong(sophuc2);
        sophuc1.Tru(sophuc2);
        sophuc1.Nhan(sophuc2);
        sophuc1.Thuong(sophuc2);
                
    }
    
}
