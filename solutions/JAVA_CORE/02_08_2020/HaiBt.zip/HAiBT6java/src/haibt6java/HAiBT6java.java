/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haibt6java;

/**
 *
 * @author topmu
 */
public class HAiBT6java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      hinhchunhat hcn = new hinhchunhat();
      hcn.Nhap();
      hcn.Dien_Tich();
      hcn.CHu_vi();
    }
    
}
