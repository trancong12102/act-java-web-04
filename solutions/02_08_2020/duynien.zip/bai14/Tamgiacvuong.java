/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14;

import java.util.Scanner;

/**
 *
 * @author tu070
 */
public class Tamgiacvuong extends Tamgiac {

    public Tamgiacvuong() {

    }

    public Tamgiacvuong(int a, int b, int c) {
        super(a, b, c);
    }
    void testTGV() {
        if (getC() * getC() == getA() * getA() + getB() * getB() || getA() * getA() == getC() * getC() + getB() * getB() || getB() * getB() == getA() * getA() + getC() * getC()) {
            System.out.println("Tam giac vuong");
        } else {
            System.out.println("k phai tam giac vuong");
        }
    }

}
