/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14;

import java.util.Scanner;

/**
 *
 * @author tu0704
 * 
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Tamgiacvuong tgv = new Tamgiacvuong();
        tgv.iPtgv();
        tgv.testTGV();
        Tamgiaccan tgc = new Tamgiaccan();
        tgc.iPtgv();
        tgc.testTGC();
        Tamgiacdeu tgd = new Tamgiacdeu();
        tgd.iPtgv();
        tgd.testTGD();
        // TODO code application logic here
    }

}
