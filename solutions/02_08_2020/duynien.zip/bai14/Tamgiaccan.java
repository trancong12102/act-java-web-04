/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14;

import java.util.Scanner;

/**
 *
 * @author tu070
 */
public class Tamgiaccan extends Tamgiac {

    public Tamgiaccan() {
    }

    public Tamgiaccan(int a, int b, int c) {
        super(a, b, c);
    }

    void testTGC() {
        if ((getA() == getB()) || (getA() == getC())||getB()==getC()) {
            System.out.println("Tam giac can");
        } else {
            System.out.println("k phai tam giac can");
        }
    }

}
