/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14;

import java.util.Scanner;

/**
 *
 * @author tu070
 */
public class Tamgiacdeu extends Tamgiaccan {

    public Tamgiacdeu() {

    }

    public Tamgiacdeu(int a, int b, int c) {
        super(a, b, c);
    }

    public void testTGD() {
        if ((getA() == getB()) && (getB() == getC())) {
            System.out.println("Tam giac deu");
        } else {
            System.out.println("k phai tam giac deu");
        }
    }

}
