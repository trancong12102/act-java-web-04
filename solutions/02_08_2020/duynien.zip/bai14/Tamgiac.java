/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14;

import java.util.Scanner;


/**
 *
 * @author tu070
 */
public class Tamgiac {

    public int a;
    public int b;
    public int c;

    public Tamgiac() {
    }

    public Tamgiac(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }
    public void iPtgv() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap 3 canh tam giac: ");
        System.out.println("Nhap a: ");
        setA( sc.nextInt());
        System.out.println("Nhap b: ");
        setB(sc.nextInt());
        System.out.println("Nhap c: ");
        setC(sc.nextInt());
    }
}
