/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8;

import java.util.Scanner;

/**
 *
 * @author oOOo
 */
public class Complex {
    Element e=new Element();
    public void input(){
        System.out.println("nhap phan thuc > ");
        e.setPhanthuc(new Scanner(System.in).nextInt());
        System.out.println("nhap phan ao > ");
        e.setPhanao(new Scanner(System.in).nextInt());
    }
    public void add(Complex c1,Complex c2){
        int a=c1.e.getPhanthuc()+c2.e.getPhanthuc();
        int b=c1.e.getPhanao()+c2.e.getPhanao();
        System.out.println(" phep cong 2  so phuc: "+a+"+"+b+"i");
    }
    public void sub(Complex c1,Complex c2){
        int a=c1.e.getPhanthuc()-c2.e.getPhanthuc();
        int b=c1.e.getPhanao()-c2.e.getPhanao();
        System.out.println(" phep tru 2 so phuc: "+a+"+"+"("+b+")"+"i");
    }
    public void mul(Complex c1,Complex c2){
        int a=c1.e.getPhanthuc()*c2.e.getPhanthuc()-c1.e.getPhanao()*c2.e.getPhanao();
        int b=c1.e.getPhanthuc()*c2.e.getPhanao()+c1.e.getPhanao()*c2.e.getPhanthuc();
        System.out.println(" phep nhan 2 so phuc : "+a+"+"+"("+b+")"+"i");
    }
    public void div(Complex c1,Complex c2){
        int a1=c1.e.getPhanthuc()*c2.e.getPhanthuc()+c1.e.getPhanao()*c2.e.getPhanao();
        int a2=c1.e.getPhanao()*c2.e.getPhanthuc()-c1.e.getPhanthuc()*c2.e.getPhanao();
        int b=(int)Math.pow(c2.e.getPhanthuc(),2)+(int)Math.pow(c2.e.getPhanao(), 2);
        System.out.println("phep chia 2 phan so : "+a1+"/"+b+"+"+"("+a2+")"+"/"+b);
    }
    
}
