/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8;

/**
 *
 * @author oOOo
 */
public class Element {
    private int phanthuc;
    private int phanao;
    public Element()
    {        
    }

    public Element(int phanthuc, int phanao) {
        this.phanthuc = phanthuc;
        this.phanao = phanao;
    }

    public void setPhanthuc(int phanthuc) {
        this.phanthuc = phanthuc;
    }

    public void setPhanao(int phanao) {
        this.phanao = phanao;
    }

    public int getPhanthuc() {
        return phanthuc;
    }

    public int getPhanao() {
        return phanao;
    }
    
}
