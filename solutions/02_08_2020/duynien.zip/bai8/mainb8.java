/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8;

/**
 *
 * @author oOOo
 */
public class mainb8 {
    public static void main(String[] args) {
        Complex c=new Complex();
        Complex c1=new Complex();
        Complex c2=new Complex();
        c1.input();
        c2.input();
        c.add(c1, c2);
        c.sub(c1, c2);
        c.mul(c1, c2);
        c.div(c1, c2);
    }
}
