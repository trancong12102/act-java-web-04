/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai9;

import java.util.Scanner;

/**
 *
 * @author oOOo
 */
public class Xuly {

    Element e = new Element();

    public void input() {
        System.out.print("nhap hoanh do dau > ");
        e.setHdd(new Scanner(System.in).nextInt());
        System.out.print("nhap hoanh do cuoi > ");
        e.setHdc(new Scanner(System.in).nextInt());
        System.out.print("nhap tung do dau > ");
        e.setTdd(new Scanner(System.in).nextInt());
        System.out.print("nhap tung do cuoi > ");
        e.setTdc(new Scanner(System.in).nextInt());
    }

    public void test(Xuly x1, Xuly x2) {
        if ((x2.e.getHdc()) - x2.e.getHdd() == (x1.e.getHdc() - x1.e.getHdd()) && (x2.e.getTdc()) - x2.e.getTdd() == (x1.e.getTdc() - x1.e.getTdd())) {
            System.out.println("day la` 2 vector bang nhau ! ");
        } else {
            System.out.println("2 vector khong bang nhau");
        }
    }

    public void goc(Xuly x1, Xuly x2) {
        int a1 = x1.e.getHdc() - x1.e.getHdd();
        int b1 = x1.e.getTdc() - x1.e.getTdd();
        int a2 = x2.e.getHdc() - x2.e.getHdd();
        int b2 = x2.e.getTdc() - x2.e.getTdd();

    }

    public void module() {
        double a1 = (double) e.getHdc() - e.getHdd();
        double b1 = (double) e.getTdc() - e.getTdd();
        double module = (double) Math.sqrt((a1 * a1 + b1 * b1));
        System.out.println("Module : " + module);
    }

    public void cungphuong(Xuly x1, Xuly x2) {
        int x = -1;
        int a1 = x1.e.getHdc() - x1.e.getHdd();
        int b1 = x1.e.getTdc() - x1.e.getTdd();
        int a2 = x2.e.getHdc() - x2.e.getHdd();
        int b2 = x2.e.getTdc() - x2.e.getTdd();
        for (double i = 0.1; i < 10; i++) {
            if (a1 == i * a2 && b1 == i * b2) {
                x = 1;

            } else {
                x = 0;
            }
        }
        if (x == 1) {
            System.out.println("day la`2 vector cung phuong!");
        } else {
            System.out.println("khong la` 2 vector cung phuong!");
        }
    }

    public void cong2vector(Xuly x1, Xuly x2) {
        int a1 = x1.e.getHdc() - x1.e.getHdd();
        int b1 = x1.e.getTdc() - x1.e.getTdd();
        int a2 = x2.e.getHdc() - x2.e.getHdd();
        int b2 = x2.e.getTdc() - x2.e.getTdd();
        System.out.println("tong 2 vector la`:" + "(" + (a1 + a2) + ";" + (b1 + b2) + ")");
    }

    public void tru2vector(Xuly x1, Xuly x2) {
        int a1 = x1.e.getHdc() - x1.e.getHdd();
        int b1 = x1.e.getTdc() - x1.e.getTdd();
        int a2 = x2.e.getHdc() - x2.e.getHdd();
        int b2 = x2.e.getTdc() - x2.e.getTdd();
        System.out.println("hieu 2 vector la`:" + "(" + (a1 - a2) + ";" + (b1 - b2) + ")");
    }

    public void nhan2vector(Xuly x1, Xuly x2) {
        int a1 = x1.e.getHdc() - x1.e.getHdd();
        int b1 = x1.e.getTdc() - x1.e.getTdd();
        int a2 = x2.e.getHdc() - x2.e.getHdd();
        int b2 = x2.e.getTdc() - x2.e.getTdd();
        System.out.println("tich 2 vector la`:" + (a1  *a2 + b1 * b2) );
    }
}
