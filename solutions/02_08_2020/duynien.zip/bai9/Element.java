/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai9;

/**
 *
 * @author oOOo
 */
public class Element {
    private int hdd;
    private int tdd;
    private int hdc;
    private int tdc;
    public Element(){
        
    }        

    public Element(int hdd, int tdd, int hdc, int tdc) {
        this.hdd = hdd;
        this.tdd = tdd;
        this.hdc = hdc;
        this.tdc = tdc;
    }

    public int getHdd() {
        return hdd;
    }

    public void setHdd(int hdd) {
        this.hdd = hdd;
    }

    public int getTdd() {
        return tdd;
    }

    public void setTdd(int tdd) {
        this.tdd = tdd;
    }

    public int getHdc() {
        return hdc;
    }

    public void setHdc(int hdc) {
        this.hdc = hdc;
    }

    public int getTdc() {
        return tdc;
    }

    public void setTdc(int tdc) {
        this.tdc = tdc;
    }
            
            
}
