/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai9;

/**
 *
 * @author oOOo
 */
public class Mainb9 {
    public static void main(String[] args) {
        Xuly x=new Xuly();
        Xuly x1=new Xuly();
        Xuly x2=new Xuly();
        x1.input();
        x1.module();
        System.out.print("nhap  vector2:\n");
        x2.input();
        x2.module();
        x.test(x1, x2);
        x.cungphuong(x1, x2);
        x.cong2vector(x1, x2);
        x.tru2vector(x1, x2);
        x.nhan2vector(x1, x2);
    }
}
