/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kethuajv;

/**
 *
 * @author oOOo
 */
public class Main {

    public static void main(String[] args) {
        hinhbinhhanh h=new hinhbinhhanh();
        h.printHinh();
        h.input();
        h.compute();
        h.printAcreagePerimeter();
        Retangle r = new Retangle();
        r.printHinh();
        r.input();
        r.compute();
        r.printAcreagePerimeter();
        Stringle s = new Stringle();
        s.printHinh();
        s.input();
        s.compute();
        s.printAcreagePerimeter();

    }
}
