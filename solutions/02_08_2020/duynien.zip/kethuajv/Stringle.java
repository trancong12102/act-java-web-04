/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kethuajv;

import java.util.Scanner;

/**
 *
 * @author oOOo
 */
public class Stringle extends Retangle{
    public Stringle(){
       
    }
    public String loaiHinh(){
        return " Stringle";
    }
    public void input(){
        System.out.print("nhap canh >  ");
        setWidth(new Scanner(System.in).nextFloat());  
        setLength(getWidth());
    }
}
