/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kethuajv;

import java.util.Scanner;


abstract class Dagiac {
   String hinh;
   double Acreage;
   double Perimeter;

    
    public String loaiHinh(){
       
        return " ";
    }
    public void printHinh(){
        System.out.println("  "+loaiHinh());
    }
    abstract void compute();
    
    public void printAcreagePerimeter(){
        System.out.println("Acreage is "+Acreage);
        System.out.println("Perimeter is "+Perimeter);
    }
}
