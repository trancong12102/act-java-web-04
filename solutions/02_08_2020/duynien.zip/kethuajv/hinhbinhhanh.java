/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kethuajv;

import java.util.Scanner;

/**
 *
 * @author oOOo
 */
public class hinhbinhhanh extends Dagiac{
    float length;
    float width;
    float height;
    public hinhbinhhanh(){
      
    }

    public hinhbinhhanh(float length,float width, float height) {
        this.length = length;
        this.width=width;
        this.height = height;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }
    
    public String loaiHinh(){
        return ":Parallelogram";
    }
    
    public void input(){    
        System.out.print("input length > ");
        setLength( new Scanner(System.in).nextFloat());  
        System.out.print("input width > ");
        setWidth(new Scanner(System.in).nextFloat());
        System.out.print("input height > ");
        setHeight( new Scanner(System.in).nextFloat()); 
   
    }
    public void compute(){
        Perimeter=(getLength()+getWidth())*2;
        Acreage=getLength()*getHeight();
    }
}
