/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kethuajv;

import java.util.Scanner;

/**
 *
 * @author oOOo
 */
public class Retangle extends hinhbinhhanh{  
    public String loaiHinh(){
        return "Retangle";
    }
    
    public void input(){    
        System.out.print("input length > ");
        setLength( new Scanner(System.in).nextFloat());    
        System.out.print("input width > ");
        setWidth(new Scanner(System.in).nextFloat()); 

    }
    public void compute(){    
        Acreage=getLength()*getWidth();
        Perimeter=(getLength()+getWidth())*2;
    }
   /*public void Raw(){
        int i,j;
        if(a >= (int)a+0.5){
            if(b>=(int)b+0.5){
            for(i=0;i<(int)a+1;i++){
                for(j=0;j<(int)b+1;j++){
                    System.out.print("*");          
                }
                System.out.println(" ");
            }
            }
            if(b<(int) b+0.5){
                for(i=0;i<(int)a+1;i++){
                for(j=0;j<(int)b;j++){
                    System.out.print("*");          
                }
                System.out.println(" ");
            }
            }
                
        }
        else{
            if(b>=(int)b+0.5){
            for(i=0;i<(int)a;i++){
                for(j=0;j<(int)b+1;j++){
                    System.out.print("*");          
                }
                System.out.println(" ");
            }
            }
            if(b<(int) b+0.5){
                for(i=0;i<(int)a;i++){
                for(j=0;j<(int)b;j++){
                    System.out.print("*");          
                }
                System.out.println(" ");
            }
            }
        }
}*/
}

