/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6;

/**
 *
 * @author oOOo
 */
public class Mainb6 {
    public static void main(String[] args) {
        chunhat r=new chunhat();
        r.nhap();
        r.computeAcreage();
        r.computePerimeter();
    }
}
