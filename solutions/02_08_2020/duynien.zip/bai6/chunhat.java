/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6;

import java.util.Scanner;

/**
 *
 * @author oOOo
 */
public class chunhat {
    private double length;
    private double width;
    
    public chunhat(){
        
    }

    public chunhat(double length, double width) {
        this.length = length;
        this.width = width;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public double getWidth() {
        return width;
    }
    public void nhap(){
        System.out.print("input length > > :");
        setLength(new Scanner(System.in).nextDouble());
        System.out.print("input width > > :");
        setWidth(new Scanner(System.in).nextDouble());
    }
    public void computeAcreage(){
        double Acreage=getLength()*getWidth();
        System.out.println("Acreage of Rectangle is: "+Acreage);
    }
    public void computePerimeter(){
        double Perimeter=(getLength()+getWidth())*2;
        System.out.println("Perimeter of Rectangle is : "+Perimeter);
    }
    
}
