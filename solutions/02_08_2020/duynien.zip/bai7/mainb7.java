/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7;

/**
 *
 * @author oOOo
 */
public class mainb7 {
    public static void main(String[] args) {
        Fraction f=new Fraction();
        Fraction f1=new Fraction();
        Fraction f2=new Fraction();
        f1.inputFraction();
        f1.printFraction();
        f1.inverse();
        f2.inputFraction();
        f2.printFraction();
        f2.inverse();
        System.out.println("=============================================");
        f.add(f1, f2);
        f.sub(f1, f2);
        f.mul(f1, f2);
        f.div(f1, f2);
    }
}
