/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7;

import java.util.Scanner;

/**
 *
 * @author oOOo
 */
public class Fraction {
    Element e=new Element();
    public int Ucln(int a,int b){
        if (a<0) a=Math.abs(a);
        if(b<0) b=Math.abs(b);
        while(a!=b){
            if(a>b)
                a=a-b;
            if(b>a)
                b=b-a;
        }
        return a;
    }
    public void inputFraction(){
        System.out.println("nhap tu so:");
        e.setTu(new Scanner(System.in).nextInt());
        System.out.println("nhap tu so:");
        e.setMau(new Scanner(System.in).nextInt());
    }
    public void printFraction(){
        System.out.println(" phan so đã tối giản :"+(e.getTu()/Ucln(e.getTu(), e.getMau()))+"/"+(e.getMau()/Ucln(e.getTu(), e.getMau())));      
    }
    public void inverse(){
       int tu=e.getMau();
       int mau=e.getTu();
        System.out.println("phân số nghich đảo: "+tu+"/"+mau);
       
    }
    public void add(Fraction f1 ,Fraction f2){
        int tu = f1.e.getTu()*f2.e.getMau()+f2.e.getTu()*f1.e.getMau();
        int mau=f1.e.getMau()*f2.e.getMau();
        System.out.println(" tong 2 phan so :"+(tu/Ucln(tu, mau))+"/"+(mau/Ucln(mau, tu)));
    }
     public void sub(Fraction f1 ,Fraction f2){
        int tu = f1.e.getTu()*f2.e.getMau()-f2.e.getTu()*f1.e.getMau();
        int mau=f1.e.getMau()*f2.e.getMau();
        System.out.println("hiệu 2 phan so :"+(tu/Ucln(tu, mau))+"/"+(mau/Ucln(mau, tu)));
    } 
    public void mul(Fraction f1 ,Fraction f2){
        int tu = f1.e.getTu()*f2.e.getTu();
        int mau=f1.e.getMau()*f2.e.getMau();
        System.out.println("nhan  2 phan so :"+(tu/Ucln(tu, mau))+"/"+(mau/Ucln(mau, tu)));
    }    
    public void div(Fraction f1 ,Fraction f2){
        int tu = f1.e.getTu()*f2.e.getMau();
        int mau=f1.e.getMau()*f2.e.getTu();
        System.out.println("chia 2 phan so :"+(tu/Ucln(tu, mau))+"/"+(mau/Ucln(mau, tu)));
    }
     
}
