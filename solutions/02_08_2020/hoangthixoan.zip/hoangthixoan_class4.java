/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main_bai4;

import java.util.Scanner;

/**
 *
 * @author iTplusHN
 */
public final class Prime {
    private int a;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }
    

    public Prime() {
    }
    public Prime(int x){
        if(isPrime(x)){
            this.a = x;
            System.out.printf("%d la SNT ",x);
            System.out.println("\n SNT tiep theo la:"+this.nextPrime());
            
        }else {
            System.out.printf("%d khong la SNT",x);
        }
        
    }

   
    public boolean isPrime(int x){
        for (int i = 2; i <= Math.sqrt(x); i++) {
            if(x % i == 0){
                return false;
            }
            
        }
        return true;
    }
    public int nextPrime(){
        int numb = this.a + 1;
        while (!isPrime(numb)){
            numb ++;
            
        }return numb;
    }
}
    
    

