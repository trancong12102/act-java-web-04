/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main_bai6;

import java.util.Scanner;

/**
 *
 * @author iTplusHN
 */
public class Rectangle {
    private int a;
    private int b;
    
    public Rectangle(){
        
    }
    public Rectangle(int a, int b){
        this.a = a;
        this.b = b;
        
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }
    public void inputInfo(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap chieu dai cua HCN: ");
        a = Integer.parseInt(sc.nextLine());
        System.out.println("Nhap chieu rong cua HCN: ");
        b = Integer.parseInt(sc.nextLine());
        
                
    }
    public void dientich(){
        float S;
        S = a * b;
        System.out.printf("\nDien tich cua HCN la : %.2f", S);
    }
    public void chuvi(){
        int P;
        P = (a + b)*2;
        System.out.printf("\nChu vi cua HCN la : %d",P);
    }
    
    
}

    

