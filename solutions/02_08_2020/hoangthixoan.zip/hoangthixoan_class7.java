/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main_bai7;

import java.util.Scanner;

/**
 *
 * @author iTplusHN
 */
public class Fraction {
    
    private int tuso;
    private int mauso;
    
    public Fraction() {
        
    }
    
    public Fraction(int tuso, int mauso) {
        this.tuso = tuso;
        this.mauso = mauso;
    }
    
    public int getTuso() {
        return tuso;
    }
    
    public void setTuso(int tuso) {
        this.tuso = tuso;
    }
    
    public int getMauso() {
        return mauso;
    }
    
    public void setMauso(int mauso) {
        this.mauso = mauso;
    }
    
    public void inputInfo() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap tu so cua PS :");
        tuso = Integer.parseInt(sc.nextLine());
        System.out.print("Nhap mau so cua PS :");
        mauso = Integer.parseInt(sc.nextLine());
        System.out.print("\nPhan so rut gon la:");
        
    }

    public void phanSo() {
        if (this.mauso == 1) {
            System.out.print(this.tuso);
            
        } else {
            System.out.print(this.tuso + "/" + this.mauso);
        }
        
    }
    
    public int UCLN(int a , int b) {
        if(a%b != 0){
            return this.UCLN(b, a%b);
        }else
        return b ;
    }
    
    public void rutGon() {
        
        int i = UCLN(this.tuso, this.mauso);
        this.setTuso(this.tuso/ i);
        this.setMauso(this.mauso/ i); 
    }
    
    public void nghichDao(){
        Fraction sc = new Fraction();
        System.out.print("\nPhan so dao nguoc la :");
        if(this.tuso == 1){
            System.out.print(this.mauso);
        }else {
            System.out.print(this.mauso + "/" + this.tuso);
        }
        
    }

    public void congPS() {
        Fraction add = new Fraction();
        if (this.mauso == this.mauso){
           add.setTuso(this.tuso + this.tuso);
           add.setMauso(this.mauso);
        }else{
        add.setTuso(this.tuso*this.mauso + this.tuso*this.mauso);
        add.setMauso(this.mauso*this.mauso);
        }
        add.rutGon();
        System.out.print("\nTong 2 phan so la :");
        add.phanSo();
        System.out.println();
        
        
        
    }
    public void truPS(){
        Fraction sub = new Fraction();
        if(this.mauso ==  this.mauso){
            sub.setTuso(this.tuso - this.tuso);
            sub.setMauso(this.mauso);
        } else{
            sub.setTuso(this.tuso*this.mauso - this.tuso*this.mauso);
            sub.setMauso(this.mauso* this.mauso);
        }
        sub.rutGon();
        System.out.print("\nHieu cua 2 phan so la:");
        sub.phanSo();
        System.out.println();
        
        
    }
    public void nhanPS(){
        Fraction mul = new Fraction();
        mul.setTuso(this.tuso* this.tuso);
        mul.setMauso(this.mauso* this.mauso);
        mul.rutGon();
        System.out.print("\nTich 2 phan so la :");
        mul.phanSo();
    }
    public void chiaPS(){
        Fraction div = new Fraction();
        div.setTuso(this.tuso * this.mauso);
        div.setMauso(this.mauso * this.tuso);
        div.rutGon();
        System.out.print("\nPhep chia 2 phan so la:");
        div.phanSo();
    }
    public void printInfo(){
        this.phanSo();
        this.nghichDao();
        this.rutGon();
        this.congPS();
        this.truPS();
        this.nhanPS();
        this.chiaPS();
        this.UCLN(tuso, tuso);
       
    }
    
}
