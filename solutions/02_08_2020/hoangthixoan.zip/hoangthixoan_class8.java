/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main_bai8;

import java.util.Scanner;

/**
 *
 * @author iTplusHN
 */
public class soPhuc {

    private float thuc;
    private float ao;

    public soPhuc() {
    }
 
    

    public soPhuc(float thuc, float ao) {
        this.thuc = thuc;
        this.ao = ao;
    }

    public float getThuc() {
        return thuc;
    }

    public void setThuc(float thuc) {
        this.thuc = thuc;
    }

    public float getAo() {
        return ao;
    }

    public void setAo(float ao) {
        this.ao = ao;
    }

    //
    public void so_phuc() {
        if (this.ao == 0) {
            System.out.println(this.thuc);

        } else {
            System.out.println(this.thuc + "+" + this.ao + "i");
        }
    }//

    public void tong(soPhuc b) {
        soPhuc add = new soPhuc();
        if (this.ao == 0) {
            add.setThuc(this.thuc + b.thuc);

        } else {
            add.setThuc(this.thuc + b.thuc);
            add.setAo(this.ao + b.ao);
        }
        System.out.println("\nTong cua 2 so phuc la :");
        add.so_phuc();
    }
    public void hieu(soPhuc b){
        soPhuc sub = new soPhuc();
        if(this.ao == 0){
           sub.setThuc(this.thuc -  b.thuc);
        }else{
            sub.setThuc(this.thuc - b.thuc);
            sub.setAo(this.ao - b.ao);
        }
        System.out.println("Hieu cua 2 so phuc la:");
        sub.so_phuc();
    }
    public void nhan(soPhuc b){
        soPhuc mul = new soPhuc();
        if(this.ao == 0){
            mul.setThuc(this.thuc * b.thuc);
        }else{
            mul.setThuc(this.thuc * b.thuc - ao* b.ao);
            mul.setAo(this.thuc* b.ao + this.ao* b.thuc);
            
        }
        System.out.println("Nhan 2 so phuc la:");
        mul.so_phuc();
    }
    public void chia(soPhuc b){
        soPhuc div = new soPhuc();
        if (this.ao == 0){
            div.setThuc(this.thuc / b.thuc);
        }else{
            div.setThuc((this.thuc*b.thuc+this.ao*b.ao)/(b.thuc*b.thuc+ b.ao*b.ao));
            div.setAo((b.thuc*this.ao- this.thuc*b.ao)/(b.thuc*b.thuc+ b.ao*b.ao));
        }
        System.out.println("Phep chia 2 so phuc la :");
        div.so_phuc();
    }

}
