/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main_bai8;

import java.util.Scanner;

/**
 *
 * @author iTplusHN
 */
public class Main_bai8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.println("so phuc thu nhat la-->");
        System.out.println("Phan thuc la: ");
        float x = sc.nextFloat();
        sc.nextLine();
        System.out.println("Phan ao la: ");
        float y = sc.nextFloat();
        
        soPhuc SP1 = new soPhuc(x,y);
        System.out.println("so phuc thu hai la --> ");
        System.out.println("Phan thuc la: ");
         float m= sc.nextFloat();
        sc.nextLine();
        System.out.println("Phan ao la: ");
         float n= sc.nextFloat();
         
        
        soPhuc SP2 = new soPhuc(m,n);
        SP1.tong(SP2);
        SP1.hieu(SP2);
        SP1.nhan(SP2);
        SP1.chia(SP2);
    }
    
}
